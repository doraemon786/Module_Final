package com.cg.springplp.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cg.springplp.model.Admin;
import com.cg.springplp.service.AdminService;

@Controller
public class CapstoreController 
{
	@Autowired
	AdminService aser;
	@RequestMapping("/")
	public String blankPage()
	{
		System.out.println("Hello");
		String view="home";
		return view;
		
	}
	
	@RequestMapping("/AdminLogin")
	public String AdminLogin(Model model) {
		String view="AdminLogin";
		model.addAttribute("admin", new Admin());
		return view;
	}
	
	@RequestMapping(value="/adminlogin",method=RequestMethod.POST)
	public String Delete(@Valid @ModelAttribute("Admin") Admin a ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="AdminLogin";
		return view;
	}
	else
	{
		Boolean flag=aser.checklogin(a);
		if(flag==true)
		{
		model.addAttribute("msg","Welcome");
		
		}
		ServletContext context=req.getServletContext();
		context.setAttribute("Admindetails", a);
		view="AdminHomePage";
		return view;
		
	}
	}
}
