package com.cg.springplp.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;




@Entity
@Table(name="product")
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	@NotBlank(message="This field can't be empty")
	private String productName;
	@NotBlank(message="This field can't be empty")
	private double productPrice;
	
	private ProductCategory productCategory;
	@NotBlank(message="This field can't be empty")
	private int productQuantity;
	
	private double productRating;
	@OneToMany (cascade=CascadeType.ALL)
	
	private List<Feedback> feedbacks;
	@ManyToMany(cascade = CascadeType.MERGE)
    @JoinTable(name = "MERCHANT_PRODUCT", 
        joinColumns = { @JoinColumn(name = "productId") }, 
        inverseJoinColumns = { @JoinColumn(name = "merchantId") })
	List<Merchant> merchants;

	public List<Feedback> getFeedbacks() {
		return feedbacks;
	}
	public void setFeedbacks(Feedback feedback) {
		this.feedbacks.add(feedback);
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public ProductCategory getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(ProductCategory productCategory) {
		this.productCategory = productCategory;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public double getProductRating() {
		return productRating;
	}
	public void setProductRating(double productRating) {
		this.productRating = productRating;
	}
	public List<Merchant> getMerchants() {
		return merchants;
	}
	public void setMerchants(Merchant merchant) {
		this.merchants.add(merchant);
	}
	/*@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productCategory=" + productCategory + ", productQuantity=" + productQuantity + ", productRating="
				+ productRating + ", merchants=" + merchants + "]";
	}
	
	*/

}
