package com.cg.springplp.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="pincodeList")
public class PincodesDeliverable 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@NotNull(message="This field cannot be empty")
	private int pincode;
	//@NotEmpty(message="This field cannot be empty")
	@ElementCollection
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="merchant_pin")
	private List<Merchant> merchant = new ArrayList<Merchant>();
	
	
	public List<Merchant> getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant.add(merchant);
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	
	
}
