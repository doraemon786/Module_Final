package com.cg.springplp.service;

public interface MerchantService {

}
