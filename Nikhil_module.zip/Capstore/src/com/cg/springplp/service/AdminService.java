package com.cg.springplp.service;

import com.cg.springplp.model.Admin;

public interface AdminService {

	
	public boolean checklogin(Admin a);
}
