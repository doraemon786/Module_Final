package com.cg.springplp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springplp.dao.AdminDao;
import com.cg.springplp.model.Admin;
@Service
public class AdminServiceImpl implements AdminService{
@Autowired
AdminDao adao;
	
	@Override
	public boolean checklogin(Admin a) {
		
		return adao.checklogin(a);
	}

}
