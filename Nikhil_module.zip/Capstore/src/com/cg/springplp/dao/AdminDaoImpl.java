package com.cg.springplp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cg.springplp.model.Admin;
@Repository
public class AdminDaoImpl implements AdminDao{

	@PersistenceContext
	private EntityManager manager;
	@Override
	public boolean checklogin(Admin a) {
	//	int rowocunt=JdbcTemplate.queryForInt("select * from Admin"+" where Admin_name=? and Admin_pwd=?",a.getAdminName(),a.getAdminPwd());
Admin a=	manager.find(Admin.class, a.getAdminName(), a.getAdminPwd());		
	if(rowocunt==1)
		{
			return true;
		}
		return false;
	}

}
