package com.cg.springplp.dao;

import com.cg.springplp.model.Admin;

public interface AdminDao {

	boolean checklogin(Admin a);

}
