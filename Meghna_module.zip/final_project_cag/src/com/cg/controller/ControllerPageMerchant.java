package com.cg.controller;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.model.Product;
import com.cg.services.IService;



@Controller
public class ControllerPageMerchant {
	
	@Autowired
	IService prodSer;
	
	@RequestMapping("/")
	public String showIndex() {
		String view = "index";
		return view;
	}
	@RequestMapping("/HomePage")
	public String HomePage()
	{
		String view = "HomePage";
		return view;	
	}
	
	@RequestMapping("/addproductcall")
	public String addproductcall(Model model) {
		String view="addproduct";
		model.addAttribute("Product", new Product());
		return view;
	}
	
	
	@RequestMapping("/deleteproduct")
	public String deletecall(Model model) {
		String view="Delete";
		model.addAttribute("Product", new Product());
		return view;
	}
	
	@RequestMapping(value="/deleteProduct",method=RequestMethod.POST)
	public String Delete(@Valid @ModelAttribute("Product") Product p ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="Delete";
		return view;
	}
	else
	{
		prodSer.delete(p.getProd_id(), p.getProd_quantity());
		model.addAttribute("msg","succesfully deleted");
		view="successPage";
		return view;
		
	}
	}
	
	@RequestMapping(value="/addproduct",method=RequestMethod.POST)
	public String add(@Valid @ModelAttribute("Product") Product p ,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="";
	if(bindingResult.hasErrors())
	{
		view="addproduct";
		return view;
	}
	else
	{
		prodSer.add(p);
		model.addAttribute("msg","succesfully added");
		view="successPage";
		return view;
		
	}
	}
	
	@RequestMapping("/ProductDetails")
	public String fetchall(Model model,HttpServletRequest request)
	{
	    String view="";
		List<Product> prod=prodSer.fetchall();
		ServletContext context=request.getServletContext();
		context.setAttribute("details", prod);
		view="ProductDetails";
		return view;
	}
	
	
}
	