package com.cg.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.model.Product;

public interface IService {

	public boolean delete(int prod_id,int prod_quantity);
	public Product add(Product p);
	public List<Product> fetchall();
	
}
