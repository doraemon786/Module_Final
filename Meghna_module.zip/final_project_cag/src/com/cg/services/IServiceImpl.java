package com.cg.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.Idao;

import com.cg.model.Product;

@Service
@Transactional
public class IServiceImpl implements IService{
@Autowired
Idao idao;
	@Override
	public boolean delete(int prod_id, int prod_quantity) {
		
		return idao.delete(prod_id, prod_quantity) ;
		
		
	}
	@Override
	public Product add(Product p) {
	
		return idao.add(p);
	}
	@Override
	public List<Product> fetchall() {
		return idao.fetchall();
		
		
	}

}
