package com.cg.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Merchant {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int merchant_id;
String merchant_name;
String phno;
String address;
String username;
String password;
String email;
String merchant_type;
double merhchant_rating;


public Merchant(int merchant_id, String merchant_name, String phno, String address, String username, String password,
		String email, String merchant_type, double merhchant_rating) {
	super();
	this.merchant_id = merchant_id;
	this.merchant_name = merchant_name;
	this.phno = phno;
	this.address = address;
	this.username = username;
	this.password = password;
	this.email = email;
	this.merchant_type = merchant_type;
	this.merhchant_rating = merhchant_rating;
}


public String getEmail() {
	return email;
}


public void setEmail(String email) {
	this.email = email;
}


public String getMerchant_type() {
	return merchant_type;
}


public void setMerchant_type(String merchant_type) {
	this.merchant_type = merchant_type;
}


public double getMerhchant_rating() {
	return merhchant_rating;
}


public void setMerhchant_rating(double merhchant_rating) {
	this.merhchant_rating = merhchant_rating;
}


public String getUsername() {
	return username;
}


public void setUsername(String username) {
	this.username = username;
}


public String getPassword() {
	return password;
}


public void setPassword(String password) {
	this.password = password;
}


public int getMerchant_id() {
	return merchant_id;
}
public void setMerchant_id(int merchant_id) {
	this.merchant_id = merchant_id;
}
public String getMerchant_name() {
	return merchant_name;
}
public void setMerchant_name(String merchant_name) {
	this.merchant_name = merchant_name;
}
public String getPhno() {
	return phno;
}
public void setPhno(String phno) {
	this.phno = phno;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


@Override
public String toString() {
	return "Merchant [merchant_id=" + merchant_id + ", merchant_name=" + merchant_name + ", phno=" + phno + ", address="
			+ address + ", username=" + username + ", password=" + password + ", email=" + email + ", merchant_type="
			+ merchant_type + ", merhchant_rating=" + merhchant_rating + "]";
}







}

