package com.cg.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Product {
	@Id@GeneratedValue(strategy=GenerationType.AUTO)
	int prod_id;
	String prod_name;
	String prod_rate;
	Double rating;
	int prod_sold;
	int prod_quantity;
	String product_category;
	@ManyToOne
	Merchant merhchant;
	
	
	


	public Product(int prod_id, String prod_name, String prod_rate, Double rating, int prod_sold, int prod_quantity,
			String product_category, Merchant merhchant) {
		super();
		this.prod_id = prod_id;
		this.prod_name = prod_name;
		this.prod_rate = prod_rate;
		this.rating = rating;
		this.prod_sold = prod_sold;
		this.prod_quantity = prod_quantity;
		this.product_category = product_category;
		this.merhchant = merhchant;
	}




	public Product() {
		// TODO Auto-generated constructor stub
	}

	
	

	public String getProduct_category() {
		return product_category;
	}




	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}




	public Double getRating() {
		return rating;
	}


	public void setRating(Double rating) {
		this.rating = rating;
	}


	public int getProd_sold() {
		return prod_sold;
	}


	public void setProd_sold(int prod_sold) {
		this.prod_sold = prod_sold;
	}


	public int getProd_id() {
		return prod_id;
	}


	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}


	public Merchant getMerhchant() {
		return merhchant;
	}


	public void setMerhchant(Merchant merhchant) {
		this.merhchant = merhchant;
	}


	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getProd_rate() {
		return prod_rate;
	}
	public void setProd_rate(String prod_rate) {
		this.prod_rate = prod_rate;
	}
	public int getProd_quantity() {
		return prod_quantity;
	}
	public void setProd_quantity(int prod_quantity) {
		this.prod_quantity = prod_quantity;
	}




	@Override
	public String toString() {
		return "Product [prod_id=" + prod_id + ", prod_name=" + prod_name + ", prod_rate=" + prod_rate + ", rating="
				+ rating + ", prod_sold=" + prod_sold + ", prod_quantity=" + prod_quantity + ", product_category="
				+ product_category + ", merhchant=" + merhchant + "]";
	}


	
	

}
