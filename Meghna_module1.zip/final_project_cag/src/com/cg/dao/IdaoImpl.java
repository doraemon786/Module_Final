package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.model.Product;

@Repository
@Transactional
public class IdaoImpl implements Idao {
	@PersistenceContext
	private EntityManager manager;
	@Override
	public boolean delete(int prod_id, int prod_quantity) {
		
		Product p=manager.find(Product.class, prod_id);
		if(prod_quantity==p.getProd_quantity())
		{
			manager.remove(p);
		}
		else
		{
			p.setProd_quantity(p.getProd_quantity()-prod_quantity);
		}
		return false;
		
	}
	@Override
	public Product add(Product p) {
		
		manager.persist(p);
		return p;
	}
	@Override
	public List<Product> fetchall() {
		Query q=manager.createQuery("from Product");
	List<Product> p= new ArrayList<Product>();
	p=q.getResultList();
	return p;
		
		
	}

}
