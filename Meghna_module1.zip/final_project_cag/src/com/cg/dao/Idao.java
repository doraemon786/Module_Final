package com.cg.dao;

import java.util.List;

import com.cg.model.Product;

public interface Idao {
	public boolean delete(int prod_id,int prod_quantity);
	public Product add(Product p);
	public List<Product> fetchall();
}
